"""Single source for the application version used by server, packages and builds."""
VERSION='0.6.12'
